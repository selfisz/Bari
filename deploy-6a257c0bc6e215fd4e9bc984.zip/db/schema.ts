import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const appState = pgTable("app_state", {
  key: text().primaryKey(),
  value: text().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});
