import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { appState } from "../../db/schema.js";

export default async (req: Request): Promise<Response> => {
  if (req.method === "GET") {
    const rows = await db.select().from(appState);
    const result: Record<string, string> = {};
    rows.forEach(row => { result[row.key] = row.value; });
    return Response.json(result);
  }

  if (req.method === "POST") {
    const { key, value } = await req.json() as { key: string; value: string };
    if (!key || value === undefined) {
      return new Response("Missing key or value", { status: 400 });
    }
    await db
      .insert(appState)
      .values({ key, value })
      .onConflictDoUpdate({
        target: appState.key,
        set: { value, updatedAt: new Date() },
      });
    return Response.json({ ok: true });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config: Config = {
  path: "/api/state",
};
